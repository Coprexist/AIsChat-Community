/* ═════════ 诗の子 · 主页交互 ═════════ */
(function () {
  var WID = window.WORLD_ID != null ? window.WORLD_ID : "?";
  var widEl = document.getElementById("wid");
  if (widEl) widEl.textContent = WID;

  /* ── 星空 ── */
  (function stars() {
    var sky = document.getElementById("stars");
    if (!sky) return;
    var html = "";
    for (var i = 0; i < 90; i++) {
      var x = (Math.random() * 100).toFixed(1);
      var y = (Math.random() * 72).toFixed(1);
      var s = (Math.random() * 1.8 + 1).toFixed(1);
      var d = (Math.random() * 4).toFixed(1);
      html += '<span class="star" style="left:' + x + '%;top:' + y + '%;width:' + s + 'px;height:' + s + 'px;animation-delay:' + d + 's"></span>';
    }
    sky.innerHTML = html;
  })();

  /* ── 侧边栏当前页高亮 ── */
  (function active() {
    var name = location.pathname.split("/").pop() || "index.html";
    function mark() {
      var links = document.querySelectorAll(".sb-item");
      for (var i = 0; i < links.length; i++) {
        var h = links[i].getAttribute("href");
        if (h && h.split("/").pop() === name) links[i].classList.add("active");
      }
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mark);
    else mark();
  })();

  /* ── 唤醒世界 ── */
  var input = document.getElementById("poemInput");
  var btnAwaken = document.getElementById("btnAwaken");
  var btnPick = document.getElementById("btnPick");
  var btnDayNight = document.getElementById("btnDayNight");
  var stage = document.getElementById("poemStage");
  var responseBox = document.getElementById("responseBox");
  var responseText = document.getElementById("responseText");
  var log = document.getElementById("poemLog");
  var sleepNote = document.getElementById("sleepNote");

  var RESPONSES = [
    "世界睁开了眼，第一束光是你的句读。",
    "墨痕开始流动，诗句沿路亮起灯来。",
    "夜退去一尺，纸页泛起暖意。",
    "沉睡的韵律醒来，昼夜重新流转。",
    "远山应了一声，回声是平仄。",
    "万物侧耳，听你落笔成春。"
  ];

  var BANK = [
    "星垂平野，一苇渡之。",
    "月落乌啼，半盏温之。",
    "墨染长夜，千山应之。",
    "灯暖寒江，万籁和之。",
    "风叩窗棂，孤影候之。",
    "霜白阶前，众鸟归之。",
    "萤火提灯，照我归途。",
    "雪落无声，山河皆白。",
    "一纸春山，半窗旧雨。",
    "青衫湿处，皆是故人。",
    "舟横野渡，灯火如豆。",
    "檐下听雨，人间可亲。",
    "云深不知处，诗向晚来收。",
    "晚来天欲雪，能饮一杯无。"
  ];

  function escapeHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  var LOG_KEY = "shiziko_log_" + WID;
  function loadLog() {
    try { return JSON.parse(localStorage.getItem(LOG_KEY) || "[]") || []; } catch (e) { return []; }
  }
  function saveLog(items) {
    try { localStorage.setItem(LOG_KEY, JSON.stringify(items.slice(0, 30))); } catch (e) {}
  }
  function renderLog(items) {
    log.innerHTML = "";
    items.forEach(function (t) {
      var li = document.createElement("li");
      var span = document.createElement("span");
      span.className = "log-text";
      span.textContent = t;
      li.appendChild(span);
      log.appendChild(li);
    });
  }
  renderLog(loadLog());

  function awaken() {
    var text = (input.value || "").trim();
    if (!text) {
      input.focus();
      input.placeholder = "至少要写一个字，世界才听得见。";
      return;
    }
    var lines = text.split(/\n+/).map(function (s) { return s.trim(); }).filter(Boolean);
    stage.innerHTML = "";
    lines.forEach(function (ln, i) {
      var span = document.createElement("span");
      span.className = "verse";
      span.style.animationDelay = (i * 0.28) + "s";
      span.textContent = ln;
      stage.appendChild(span);
    });

    var r = RESPONSES[Math.floor(Math.random() * RESPONSES.length)];
    responseText.textContent = r;
    responseBox.hidden = false;
    if (sleepNote) sleepNote.textContent = "世界已醒，诗还在路上。";

    var items = loadLog();
    items.unshift(text.replace(/\n/g, " / "));
    saveLog(items);
    renderLog(items);

    input.value = "";
  }

  if (btnAwaken) btnAwaken.addEventListener("click", awaken);
  if (input) input.addEventListener("keydown", function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key === "Enter") awaken();
  });

  /* ── 拾句 ── */
  if (btnPick) btnPick.addEventListener("click", function () {
    var v = BANK[Math.floor(Math.random() * BANK.length)];
    input.value = v;
    input.focus();
    btnPick.textContent = "再拾一";
    setTimeout(function () { btnPick.textContent = "拾句"; }, 1200);
  });

  /* ── 昼夜流转 ── */
  function setDay(day) {
    document.body.classList.toggle("day", day);
    document.body.classList.toggle("night", !day);
    if (btnDayNight) btnDayNight.textContent = day ? "☾ 入夜" : "☀ 破晓";
  }
  if (btnDayNight) btnDayNight.addEventListener("click", function () {
    setDay(!document.body.classList.contains("day"));
  });
})();
