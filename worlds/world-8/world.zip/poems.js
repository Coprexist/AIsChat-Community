/* ═════════ 诗の子 · 诗之殿（收藏页）· 数据库版 ═════════
 * 数据流：
 *   读：优先直连世界数据库 /world/{WID}/api/data/poems.{lib,lit}
 *       失败降级 content/poems.json（世界代码同步的静态快照）→ localStorage（离线兜底）
 *   写点亮：乐观更新 → PUT poems.lit → POST /state 广播（其他页面 SSE 实时同步）
 *   SSE：/world/{WID}/events 订阅，世界代码加诗 / 他人点亮 → 实时刷新
 *   迁移：localStorage 旧收藏自动灌入数据库（一次性）
 */
(function () {
  'use strict';

  var WID = window.WORLD_ID != null && window.WORLD_ID > 0 ? window.WORLD_ID : null;
  var widEl = document.getElementById("wid");
  if (widEl) widEl.textContent = WID != null ? WID : "?";

  /* ── 星空（与主页同款） ── */
  (function stars() {
    var sky = document.getElementById("stars");
    if (!sky) return;
    var html = "";
    for (var i = 0; i < 70; i++) {
      var x = (Math.random() * 100).toFixed(1);
      var y = (Math.random() * 72).toFixed(1);
      var s = (Math.random() * 1.8 + 1).toFixed(1);
      var d = (Math.random() * 4).toFixed(1);
      html += '<span class="star" style="left:' + x + '%;top:' + y + '%;width:' + s + 'px;height:' + s + 'px;animation-delay:' + d + 's"></span>';
    }
    sky.innerHTML = html;
  })();

  /* ── 侧边栏高亮 ── */
  (function active() {
    var name = location.pathname.split("/").pop() || "index.html";
    function mark() {
      var links = document.querySelectorAll(".sb-item");
      for (var i = 0; i < links.length; i++) {
        var h = links[i].getAttribute("href");
        if (h && h.split("/").pop() === name) links[i].classList.add("active");
      }
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", mark);
    else mark();
  })();

  var grid = document.getElementById("grid");
  var litCount = document.getElementById("litCount");
  var emptyTip = document.getElementById("emptyTip");
  var dbStatus = document.getElementById("dbStatus");

  var LOG_KEY = "shiziko_log_" + WID;
  var FAV_KEY = "shiziko_fav_" + WID;
  var MIG_KEY = LOG_KEY + "_migrated";

  var API = WID != null ? "/world/" + WID + "/api" : null;
  var EVENTS = WID != null ? "/world/" + WID + "/events" : null;

  /* mode: loading / cloud(数据库) / snap(静态快照) / local(本地兜底) */
  var state = { lib: [], lit: {}, mode: "loading" };

  /* ── 存储工具 ── */
  function lsGet(k, dft) {
    try { var v = JSON.parse(localStorage.getItem(k)); return v == null ? dft : v; } catch (e) { return dft; }
  }
  function lsSet(k, v) {
    try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {}
  }

  /* ── 数据库直连 ── */
  function apiFetch(path, opts) {
    if (!API) return Promise.reject(new Error("no api"));
    return fetch(API + path, opts).then(function (res) {
      if (!res.ok) throw new Error("http " + res.status);
      return res.json();
    });
  }
  function readCloud() {
    return Promise.all([
      apiFetch("/data/poems.lib"),
      apiFetch("/data/poems.lit")
    ]).then(function (rs) {
      return { lib: rs[0].value || [], lit: rs[1].value || {} };
    });
  }
  function writeLitCloud(lit) {
    return apiFetch("/data/poems.lit", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: lit })
    });
  }
  function broadcastState(payload) {
    if (!API) return;
    fetch(API + "/state", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    }).catch(function () {});
  }

  /* ── 加载：云 → 静态快照 → 本地 ── */
  function load() {
    return readCloud().then(function (d) {
      state.mode = "cloud";
      state.lib = d.lib; state.lit = d.lit;
      setStatus("☁ 诗云相连");
      migrateOnce(d);
      return state;
    }).catch(function () {
      return fetch("content/poems.json", { cache: "no-store" }).then(function (r) {
        if (!r.ok) throw new Error("no snap");
        return r.json();
      }).then(function (s) {
        state.mode = "snap";
        state.lib = s.lib || []; state.lit = s.lit || {};
        setStatus("⛅ 离线快照");
        return state;
      }).catch(function () {
        state.mode = "local";
        state.lib = lsGet(LOG_KEY, []); state.lit = lsGet(FAV_KEY, {});
        setStatus("🕯 仅存本机");
        return state;
      });
    });
  }

  /* ── 旧数据一次性迁移（localStorage → 数据库） ── */
  function migrateOnce(cloud) {
    var oldLog = lsGet(LOG_KEY, []);
    var oldFav = lsGet(FAV_KEY, {});
    if (lsGet(MIG_KEY, false) || !oldLog.length) return;
    var lib = cloud.lib.slice();
    var lit = cloud.lit || {};
    var base = lib.length;
    oldLog.forEach(function (text, i) {
      var pid = "p" + (base + i + 1);
      lib.push({
        id: pid,
        text: String(text),
        source: "旧藏",
        created_at: Math.floor(Date.now() / 1000)
      });
      if (oldFav[i]) lit[pid] = true;
    });
    apiFetch("/data/poems.lib", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ value: lib })
    }).then(function () {
      return writeLitCloud(lit);
    }).then(function () {
      lsSet(MIG_KEY, true);
      state.lib = lib; state.lit = lit;
      broadcastState({ poems_updated: { lib: lib, lit: lit, updated_at: Math.floor(Date.now() / 1000) } });
      setStatus("☁ 旧藏已入诗云");
      render();
    }).catch(function () { /* 迁移失败，下次再试 */ });
  }

  /* ── SSE 实时订阅 ── */
  if (EVENTS) {
    try {
      var es = new EventSource(EVENTS);
      es.onmessage = function (e) {
        try {
          var d = JSON.parse(e.data);
          if (d && d.poems_updated) {
            load().then(render);
          } else if (d && d.poems_lit) {
            state.lit[d.poems_lit.id] = !!d.poems_lit.lit;
            lsSet(FAV_KEY, state.lit);
            render();
          }
        } catch (err) {}
      };
    } catch (e) {}
  }

  /* ── 状态提示 ── */
  function setStatus(t) {
    if (dbStatus) dbStatus.textContent = t;
  }

  function escapeHtml(s) {
    return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  /* ── 点亮 / 熄灯 ── */
  function toggle(pid) {
    var lit = !state.lit[pid];
    state.lit[pid] = lit;
    lsSet(FAV_KEY, state.lit);            // 本地兜底
    render();
    if (state.mode === "cloud") {
      writeLitCloud(state.lit).then(function () {
        broadcastState({ poems_lit: { id: pid, lit: lit } });
        setStatus("☁ 已存入诗云");
      }).catch(function () {
        setStatus("⚠ 云同步失败，仅存本机");
      });
    } else {
      setStatus("🕯 本地模式点亮");
    }
  }

  /* ── 渲染 ── */
  function render() {
    var verses = state.lib;
    var fav = state.lit;
    grid.innerHTML = "";

    if (!verses.length) {
      if (emptyTip) emptyTip.hidden = false;
      if (litCount) litCount.textContent = "已点亮 0 句";
      return;
    }
    if (emptyTip) emptyTip.hidden = true;

    var lit = 0;
    verses.forEach(function (p) {
      var text = p.text != null ? String(p.text) : "";
      var pid = p.id || "";
      var lines = text.split(" / ");
      var faved = !!fav[pid];
      if (faved) lit++;

      var card = document.createElement("div");
      card.className = "card" + (faved ? " faved" : "");
      card.setAttribute("data-id", pid);

      var title = document.createElement("div");
      title.className = "card-title";
      title.textContent = p.source ? "「" + p.source + "」" : "第 " + (pid.replace(/^p/, "") || "?") + " 句";

      var body = document.createElement("div");
      body.className = "card-verse";
      lines.forEach(function (ln) {
        var q = document.createElement("p");
        q.textContent = ln;
        body.appendChild(q);
      });

      var foot = document.createElement("div");
      foot.className = "card-foot";

      var src = document.createElement("span");
      src.className = "card-src";
      src.textContent = faved ? "🏮 已长明" : "✦ 未点亮";

      var act = document.createElement("button");
      act.className = "card-act";
      act.textContent = faved ? "熄灯" : "点亮";
      act.addEventListener("click", function (e) {
        e.stopPropagation();
        toggle(pid);
      });

      foot.appendChild(src);
      foot.appendChild(act);
      card.appendChild(title);
      card.appendChild(body);
      card.appendChild(foot);

      card.addEventListener("click", function () {
        var txt = text.replace(/ \/ /g, "\n");
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(txt).then(function () { flash(card, "已抄录"); });
        } else {
          flash(card, "已抄录");
        }
      });

      grid.appendChild(card);
    });

    if (litCount) litCount.textContent = "已点亮 " + lit + " 句";
  }

  var flashTimer = null;
  function flash(el, msg) {
    var old = el.style.boxShadow;
    el.style.boxShadow = "0 0 0 3px rgba(232,185,106,.5)";
    el.setAttribute("title", msg);
    clearTimeout(flashTimer);
    flashTimer = setTimeout(function () {
      el.style.boxShadow = old;
      el.removeAttribute("title");
    }, 900);
  }

  /* ── 启动 ── */
  setStatus("☁ 连接诗云…");
  load().then(render);
})();
