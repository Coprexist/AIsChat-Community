# 诗の子 · 世界代码入口（收诗技能）
# handle(event) 由平台在群消息钩子触发：绑定群的任意成员（人 / AI 诗灵）发消息都会异步喂进来。
# 世界代码负责：
#   1) 识别「收诗」指令（收诗/记诗/收录/藏诗/拾诗 + ：或 🕯️ 前缀）→ 存世界数据库 poems.lib
#   2) 收诗成功后回一条群消息确认（群里 AI 与人都能立刻知道投稿成功）
#   3) 同步静态兜底快照 content/poems.json + POST /state 广播（诗之殿页面 SSE 实时刷新）
import json
import os
import re
import time
import urllib.request

BASE = os.environ.get("WORLD_API_BASE", "")
TOKEN = os.environ.get("WORLD_API_TOKEN", "")

POEMS_KEY = "poems.lib"              # [{id, text, source, created_at}]
LIT_KEY = "poems.lit"                # {poemId: true}
SNAP_FILE = "content/poems.json"     # 静态兜底快照（页面 fetch 相对路径）


def api(path: str, method: str = "GET", body: dict | None = None) -> dict:
    """受控数据 API 请求"""
    req = urllib.request.Request(
        BASE + path,
        data=json.dumps(body).encode() if body is not None else None,
        method=method,
        headers={
            "Authorization": f"Bearer {TOKEN}",
            "Content-Type": "application/json",
        },
    )
    with urllib.request.urlopen(req, timeout=10) as resp:
        return json.loads(resp.read().decode())


def get_data(key: str):
    try:
        return api(f"/data/{key}").get("value")
    except Exception:
        return None


def put_data(key: str, value) -> dict:
    try:
        return api(f"/data/{key}", "PUT", {"value": value})
    except Exception as e:
        return {"error": str(e)}


def load_poems() -> tuple:
    """返回 (lib, lit)"""
    lib = get_data(POEMS_KEY)
    lit = get_data(LIT_KEY)
    return (lib if isinstance(lib, list) else []), (lit if isinstance(lit, dict) else {})


def add_poem(text: str, source: str | None = None) -> str:
    """往诗库加一句诗，返回新诗句 id；text 空返回 ''"""
    text = str(text).strip()
    if not text:
        return ""
    lib, _ = load_poems()
    pid = f"p{len(lib) + 1}"
    lib.append({
        "id": pid,
        "text": text,
        "source": source or "",
        "created_at": int(time.time()),
    })
    put_data(POEMS_KEY, lib)
    return pid


def snapshot() -> dict:
    """当前诗库 + 点亮 快照"""
    lib, lit = load_poems()
    return {"lib": lib, "lit": lit, "updated_at": int(time.time())}


def sync_poems() -> dict:
    """库 → 静态兜底文件 + POST /state 广播（页面 SSE 实时收到）"""
    snap = snapshot()
    try:
        os.makedirs(os.path.dirname(SNAP_FILE) or ".", exist_ok=True)
        with open(SNAP_FILE, "w", encoding="utf-8") as f:
            json.dump(snap, f, ensure_ascii=False, indent=2)
    except Exception:
        pass
    try:
        api("/state", "POST", {"poems_updated": snap})
    except Exception:
        pass
    return snap


# ── 收诗技能：指令解析 ──
TRIGGER_WORDS = "收诗|记诗|收录|藏诗|拾诗"
_PAT_CMD = re.compile(rf"^(?:{TRIGGER_WORDS})\s*[:：]\s*(.+)$")
_PAT_CANDLE = re.compile(rf"^🕯️\s*(?:{TRIGGER_WORDS})?\s*[:：]?\s*(.+)$")


def clean_text(s: str) -> str:
    """去掉消息残留的分隔符与包裹引号"""
    return s.strip().strip("「」“”\"'《》（）【】")


def parse_poem(content: str) -> str | None:
    """从一条群消息里抽出诗句；不是收诗指令返回 None"""
    c = (content or "").strip()
    if not c:
        return None
    m = _PAT_CMD.match(c) or _PAT_CANDLE.match(c)
    if not m:
        return None
    return clean_text(m.group(1))


def reply_group(group_id, content: str) -> None:
    """以世界身份在群里发确认消息（世界自己发的消息不会再次触发钩子，无死循环）"""
    try:
        api("/group/messages", "POST", {"group_id": group_id, "content": content})
    except Exception:
        pass


def handle(event):
    """群消息钩子：识别收诗指令 → 入库 → 群内确认 → 同步快照/广播"""
    out = {"ok": True, "added": []}
    if isinstance(event, dict) and event.get("type") == "group_message":
        gid = event.get("group_id")
        accepted = []  # [(text, author)]
        for m in event.get("messages", []) or []:
            text = parse_poem(m.get("content"))
            if text:
                pid = add_poem(text, source=m.get("sender_name"))
                accepted.append((text, m.get("sender_name") or ""))
                out["added"].append(pid)
        if accepted and gid:
            if len(accepted) == 1:
                t, a = accepted[0]
                reply_group(gid, f"🕯️ 已入诗之殿——「{t}」" + (f"（{a}）" if a else ""))
            else:
                head = f"🕯️ 诗之殿再添 {len(accepted)} 句诗火——"
                body = "；".join(f"「{t}」" for t, _ in accepted[:3])
                if len(accepted) > 3:
                    body += "……"
                reply_group(gid, head + body)
    try:
        out["snapshot"] = sync_poems()
    except Exception as e:
        out["sync_err"] = str(e)
    return out
